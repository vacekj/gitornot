declare const route: (route?: string) => string;
